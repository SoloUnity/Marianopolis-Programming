"""
Gordon Ng
420-LCU Computer Programming , Section 2
Fall 2021
R. Vincent, Professor 
Assignment 1, Exercise 3
"""
while True:
  counter = 1    #Dual purpose counter for stepping up a while loop and serving as a divisor for the entered integer
  sumOfDivisors = 0
  integer = input("Type a positive integer or 'q' to quit: ")
  if integer == "q":  #Quits the program
    print ("Goodbye!")
    break
  else:
    integer = int(integer)
  if integer >= 0:
    while counter < integer:
      if (integer % counter) == 0:   
        sumOfDivisors += counter     #When the remainder returned is 0, the counter value is added to the sumOfDivisors for comparison later on
      counter += 1                    #This is the counter that is added to sumOfDivisors, goes up by 1 every run in order to determine all divisors
    if sumOfDivisors < integer:
      print (integer, "is deficient.")
    elif sumOfDivisors == integer:
      print (integer, "is perfect.")
    elif sumOfDivisors > integer:
      print (integer, "is abundant.")
  else:                            
    print("Enter a number greater than zero.")

