"""
Gordon Ng
420-LCU Computer Programming , Section 2
Fall 2021
R. Vincent, Professor 
Assignment 1, Exercise 1
"""
low, high = 1 , 128         #Defines the guess range of predictedNum as between 1 - 128 for the bisection algorith at line 11
print("Please think of a number between", low, "and", high)
while True:
  predictedNum = (low + high) // 2    #Bisection algorithm applied
  print ("Is your secret number", predictedNum, "?")
  guess = input("Enter ’h’ if my guess is too high, ’l’ if too low, or ’c’ if I am correct: ")
  if guess == "h":
    high = predictedNum - 1     #Sets the upper limit of guesses as the previously predicted number
  elif guess == "l":
    low = predictedNum + 1  #Sets the low limits as 1 more than the previously predicted number, takes care of the fringe case of the upper limit
  elif guess == "c":
    print ("Yay! Your secret number was", predictedNum, "!")
    break
  else:
    print ("Your input isn't accepted, please try again")

#The largest number of guesses that my program will have to make is 8, which applies to the number 128. 

